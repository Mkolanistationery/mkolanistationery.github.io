window.NS = {
  toggleNav(){
    const nav = document.querySelector('.nav');
    nav.classList.toggle('open');
  },
  addToCart(name){
    alert(`Added to cart: ${name}`);
  },
  signup(e){
    e.preventDefault();
    const form = e.target;
    const email = form.email.value.trim();
    const msg = form.querySelector('.form-msg');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
      msg.textContent = 'Please enter a valid email.';
      return false;
    }
    msg.textContent = 'Thanks! You are subscribed.';
    form.reset();
    return false;
  },
  contact(e){
    e.preventDefault();
    const form = e.target;
    const data = Object.fromEntries(new FormData(form).entries());
    const msg = form.querySelector('.form-msg');
    if(!data.name || !data.email || !data.message){
      msg.textContent = 'Please fill in all fields.';
      return false;
    }
    msg.textContent = 'Message sent locally (demo).';
    form.reset();
    return false;
  }
};

// Year in footer
document.addEventListener('DOMContentLoaded', () => {
  const y = document.getElementById('year');
  if(y){ y.textContent = new Date().getFullYear(); }
});
