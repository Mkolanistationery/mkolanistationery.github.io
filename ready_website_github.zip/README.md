# NovaSite – GitHub Pages Ready

This is your GitHub Pages–ready static website.

## Publishing Instructions

1. Go to [GitHub](https://github.com) and log in.
2. Create a **new repository** named exactly:
   ```
   yourusername.github.io
   ```
   Replace `yourusername` with your GitHub username (lowercase).

3. Make it **Public**.

4. Unzip this ZIP file.

5. Upload **all files** (not the ZIP) into your repo.

6. Commit changes.

7. Wait 1–2 minutes, then visit:
   ```
   https://yourusername.github.io
   ```

GitHub Pages will automatically detect and host it.

---
This site is built with semantic HTML, modern CSS, and a dash of JavaScript — no build tools required.
